public class HexFormatException extends NumberFormatException {

}
