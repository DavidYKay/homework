public class NewDrawMessage {
  public static void main(String[] args) {
    NewDrawMessage newdrawmessage = new NewDrawMessage();
  }
}
