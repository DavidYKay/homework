public class FahrenheitToCelsius {
  public static void main(String[] args) {
    double fahrenheit = 100; // Say 100;
    double celsius = (5.0 / 9) * (fahrenheit - 32);
    System.out.println("Fahrenheit " + fahrenheit + " is " +
      celsius + " in Celsius");
  }
}
