public interface Edible {
  /** Describe how to eat */
  public String howToEat();
}
