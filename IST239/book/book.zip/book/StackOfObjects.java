public class StackOfObjects {
  public static void main(String[] args) {
    StackOfObjects stackofobjects = new StackOfObjects();
  }
}
