public abstract class Quiz {

}
