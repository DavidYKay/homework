import java.util.EventListener;
interface QuizListener extends EventListener {
    public void stateChanged(QuizEvent e); 
}   
