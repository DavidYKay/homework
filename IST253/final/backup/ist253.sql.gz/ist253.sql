-- phpMyAdmin SQL Dump
-- version 2.11.9.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 28, 2010 at 04:59 AM
-- Server version: 5.0.84
-- PHP Version: 5.2.13-pl0-gentoo

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ist253`
--

-- --------------------------------------------------------

--
-- Table structure for table `CUSTOMER`
--

CREATE TABLE IF NOT EXISTS `CUSTOMER` (
  `CustomerAccountNo` int(18) unsigned NOT NULL,
  `CustomerLName` char(20) default NULL,
  `CustomerFName` char(20) default NULL,
  `CustomerAddress` char(20) default NULL,
  `CustomerCity` char(20) default NULL,
  `CustomerState` char(20) default NULL,
  `CustomerZip` char(20) default NULL,
  `CustomerPhone` char(20) default NULL,
  PRIMARY KEY  (`CustomerAccountNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CUSTOMER`
--

INSERT INTO `CUSTOMER` (`CustomerAccountNo`, `CustomerLName`, `CustomerFName`, `CustomerAddress`, `CustomerCity`, `CustomerState`, `CustomerZip`, `CustomerPhone`) VALUES
(1, 'Mills', 'Julia', '1 Robin Court', 'West Windsor', 'NJ', '08550', '(609)789-1234'),
(2, 'Wells', 'Homer', '2 Robin Court', 'West Windsor', 'NJ', '08550', '(609)789-1235'),
(3, 'Norbert', 'Bob', '3 Robin Court', 'West Windsor', 'NJ', '08550', '(609)789-1236'),
(4, 'Kendall', 'Candy', '1 Colt Ave', 'West Windsor', 'NJ', '08550', '(609)123-9876'),
(5, 'Dodge', 'Mariah', '101 Village Road', 'West Windsor', 'NJ', '08550', '(732)789-1235'),
(6, 'Dodge', 'Tess', '55 Marie Court', 'West Windsor', 'NJ', '08550', '(609)587-1236'),
(7, 'Kendall', 'Joe', '86  Flock Road', 'West Windsor', 'NJ', '08550', '(732)222-9876'),
(8, 'Colan', 'Cristopher', '101 Salon Ave', 'West Windsor', 'NJ', '08550', '(609)789-1235'),
(9, 'Brazzi', 'Luke', '4 Alexander Court', 'West Windsor', 'NJ', '08550', '(609)987-0609'),
(10, 'Pilgrim', 'William', '10 Eric Circle', 'West Windsor', 'NJ', '08550', '(732)587-4454');

-- --------------------------------------------------------

--
-- Table structure for table `CUSTOMER_PRODUCT`
--

CREATE TABLE IF NOT EXISTS `CUSTOMER_PRODUCT` (
  `CustomerAccountNo` int(18) unsigned NOT NULL,
  `ProdSerNo` char(18) NOT NULL,
  `SerPlanNo` int(18) unsigned NOT NULL,
  KEY `CustomerAccountNo` (`CustomerAccountNo`),
  KEY `ProdSerNo` (`ProdSerNo`),
  KEY `SerPlanNo` (`SerPlanNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links the Customers to the Products';

--
-- Dumping data for table `CUSTOMER_PRODUCT`
--

INSERT INTO `CUSTOMER_PRODUCT` (`CustomerAccountNo`, `ProdSerNo`, `SerPlanNo`) VALUES
(1, 'W2100', 1),
(2, 'D2100', 2),
(3, 'R2100', 3),
(3, 'W2200', 8),
(4, 'O2100', 4),
(5, 'DW2100', 5),
(6, 'M2100', 6),
(7, 'S2100', 7),
(8, 'DW2100', 10),
(9, 'M2100', 9),
(10, 'W2100', 11);

-- --------------------------------------------------------

--
-- Table structure for table `DIAGNOSTIC`
--

CREATE TABLE IF NOT EXISTS `DIAGNOSTIC` (
  `DiagNo` int(18) unsigned NOT NULL auto_increment,
  `DiagBeginDate` date NOT NULL,
  `DiagEndDate` date default NULL,
  `DiagResult` varchar(20) default NULL,
  PRIMARY KEY  (`DiagNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `DIAGNOSTIC`
--

INSERT INTO `DIAGNOSTIC` (`DiagNo`, `DiagBeginDate`, `DiagEndDate`, `DiagResult`) VALUES
(1, '2009-11-01', '2009-11-01', 'P'),
(2, '2009-12-01', '2009-12-01', 'P'),
(3, '2010-01-01', '2010-01-01', 'P'),
(4, '2010-02-01', '2010-02-01', 'P'),
(5, '2010-03-01', '2010-03-01', 'P'),
(6, '2010-04-01', '2010-04-01', 'P'),
(7, '2009-10-02', '2009-10-02', 'P'),
(8, '2010-02-14', '2010-02-14', 'P'),
(9, '2009-08-14', '2009-08-14', 'P'),
(10, '2010-02-14', '2010-02-14', 'P'),
(11, '2008-06-19', '2008-06-19', 'P'),
(12, '2008-12-19', '2008-12-19', 'P'),
(13, '2009-06-19', '2009-06-19', 'F'),
(14, '2009-12-19', '2009-12-19', 'P'),
(15, '2009-10-15', '2009-10-15', 'F'),
(16, '2010-02-13', '2010-02-13', 'P'),
(17, '2010-03-13', '2010-03-13', 'F'),
(18, '2010-04-13', '2010-04-13', 'P'),
(19, '2010-03-01', '2010-03-01', 'F'),
(20, '2009-11-15', '2009-11-15', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `INVENTORY`
--

CREATE TABLE IF NOT EXISTS `INVENTORY` (
  `PartNo` char(18) NOT NULL,
  `PartName` varchar(20) NOT NULL,
  `PartAvail` tinyint(1) NOT NULL,
  `ProdType` varchar(20) NOT NULL,
  PRIMARY KEY  (`PartNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INVENTORY`
--

INSERT INTO `INVENTORY` (`PartNo`, `PartName`, `PartAvail`, `ProdType`) VALUES
('DW001', 'Pump', 1, 'Dishwasher'),
('MW003', 'Dish Spindal', 1, 'Microwave'),
('OV003', 'Oven Sensor', 1, 'Oven'),
('RG001', 'Burners', 1, 'Stove');

-- --------------------------------------------------------

--
-- Table structure for table `INVOICE`
--

CREATE TABLE IF NOT EXISTS `INVOICE` (
  `InvNo` int(18) unsigned NOT NULL auto_increment,
  `InvDate` date NOT NULL,
  `SalesTax` decimal(10,2) NOT NULL,
  `InvDueDate` date NOT NULL,
  PRIMARY KEY  (`InvNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `INVOICE`
--

INSERT INTO `INVOICE` (`InvNo`, `InvDate`, `SalesTax`, `InvDueDate`) VALUES
(1, '2009-11-01', '0.35', '2009-11-11'),
(2, '2009-12-01', '0.35', '2009-12-11'),
(3, '2010-01-01', '0.35', '2010-01-11'),
(4, '2010-02-01', '0.35', '2010-02-11'),
(5, '2010-03-01', '0.35', '2010-03-11'),
(6, '2010-04-01', '0.35', '2010-04-11'),
(7, '2009-10-02', '0.35', '2009-10-12'),
(8, '2010-02-14', '1.12', '2010-02-24'),
(9, '2009-08-14', '0.63', '2009-08-24'),
(10, '2010-02-14', '0.63', '2010-02-24'),
(11, '2008-06-19', '0.63', '2008-06-29'),
(12, '2008-12-19', '0.63', '2008-12-29'),
(13, '2009-06-19', '0.63', '2009-06-29'),
(14, '2009-12-19', '0.63', '2009-12-29'),
(15, '2009-10-15', '2.45', '2009-10-25'),
(16, '2010-02-13', '0.35', '2010-02-23'),
(17, '2010-03-13', '0.35', '2010-03-23'),
(18, '2010-04-13', '0.35', '2010-04-23'),
(19, '2010-03-01', '1.12', '2010-03-11'),
(20, '2009-11-15', '0.35', '2009-11-25');

-- --------------------------------------------------------

--
-- Table structure for table `INVOICE_SERVICE`
--

CREATE TABLE IF NOT EXISTS `INVOICE_SERVICE` (
  `InvNo` int(18) unsigned NOT NULL,
  `SerPlanNo` int(18) unsigned NOT NULL,
  KEY `InvNo` (`InvNo`),
  KEY `SerPlanNo` (`SerPlanNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Links service plans with an invoice';

--
-- Dumping data for table `INVOICE_SERVICE`
--

INSERT INTO `INVOICE_SERVICE` (`InvNo`, `SerPlanNo`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 1),
(13, 2),
(14, 3),
(15, 4),
(16, 5),
(17, 6),
(18, 7),
(19, 8),
(20, 9);

-- --------------------------------------------------------

--
-- Table structure for table `PRODUCT`
--

CREATE TABLE IF NOT EXISTS `PRODUCT` (
  `ProdSerNo` char(18) NOT NULL,
  `ProdType` varchar(18) NOT NULL,
  PRIMARY KEY  (`ProdSerNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PRODUCT`
--

INSERT INTO `PRODUCT` (`ProdSerNo`, `ProdType`) VALUES
('D2100', 'Dryer'),
('DW2100', 'Dishwasher'),
('M2100', 'Microwave'),
('O2100', 'Oven'),
('R2100', 'Refrigerator'),
('S2100', 'Stove'),
('W2100', 'Washer'),
('W2200', 'Washer');

-- --------------------------------------------------------

--
-- Table structure for table `SERVICE_PLAN`
--

CREATE TABLE IF NOT EXISTS `SERVICE_PLAN` (
  `SerPlanNo` int(18) unsigned NOT NULL auto_increment,
  `SerPlanType` varchar(20) NOT NULL,
  `SerPlanRate` decimal(10,2) NOT NULL,
  `SerPlanIssued` date NOT NULL,
  PRIMARY KEY  (`SerPlanNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `SERVICE_PLAN`
--

INSERT INTO `SERVICE_PLAN` (`SerPlanNo`, `SerPlanType`, `SerPlanRate`, `SerPlanIssued`) VALUES
(1, 'A', '5.00', '2009-10-01'),
(2, 'B', '9.00', '2008-10-02'),
(3, 'C', '16.00', '2004-02-13'),
(4, 'D', '35.00', '2009-02-14'),
(5, 'A', '5.00', '2007-12-19'),
(6, 'B', '9.00', '2009-11-06'),
(7, 'C', '16.00', '2008-07-07'),
(8, 'D', '35.00', '2010-01-13'),
(9, 'A', '5.00', '2009-03-02'),
(10, 'B', '9.00', '2009-05-12'),
(11, 'C', '16.00', '2005-08-03');

-- --------------------------------------------------------

--
-- Table structure for table `TEST_RESULTS`
--

CREATE TABLE IF NOT EXISTS `TEST_RESULTS` (
  `TestResNo` int(18) unsigned NOT NULL auto_increment,
  `ProdSerNo` char(18) default NULL,
  `DiagNo` int(18) unsigned default NULL,
  `Status` varchar(18) default NULL,
  `PartNo` char(18) default NULL,
  `EstSerDate` date default NULL,
  PRIMARY KEY  (`TestResNo`),
  KEY `DiagNo` (`DiagNo`),
  KEY `ProdSerNo` (`ProdSerNo`),
  KEY `PartNo` (`PartNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `TEST_RESULTS`
--

INSERT INTO `TEST_RESULTS` (`TestResNo`, `ProdSerNo`, `DiagNo`, `Status`, `PartNo`, `EstSerDate`) VALUES
(1, 'W2100', 1, NULL, NULL, '0000-00-00'),
(2, 'W2100', 2, NULL, NULL, '0000-00-00'),
(3, 'W2100', 3, NULL, NULL, '0000-00-00'),
(4, 'W2100', 4, NULL, NULL, '0000-00-00'),
(5, 'W2100', 5, NULL, NULL, '0000-00-00'),
(6, 'W2100', 6, NULL, NULL, '0000-00-00'),
(7, 'D2100', 7, NULL, NULL, '0000-00-00'),
(8, 'R2100', 8, NULL, NULL, '0000-00-00'),
(9, 'W2200', 9, NULL, NULL, '0000-00-00'),
(10, 'W2200', 10, NULL, NULL, '0000-00-00'),
(11, 'O2100', 11, NULL, NULL, '0000-00-00'),
(12, 'O2100', 12, NULL, NULL, '0000-00-00'),
(13, 'O2100', 13, 'Active', 'OV003', '2009-06-24'),
(14, 'O2100', 14, NULL, NULL, '0000-00-00'),
(15, 'M2100', 15, 'Active', 'MW003', '2009-10-20'),
(16, 'S2100', 16, NULL, NULL, '0000-00-00'),
(17, 'S2100', 17, 'Active', 'RG001', '2010-03-18'),
(18, 'S2100', 18, NULL, NULL, '0000-00-00'),
(19, 'DW2100', 19, 'Active', 'DW001', '2010-03-06'),
(20, 'M2100', 20, NULL, NULL, '0000-00-00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `CUSTOMER_PRODUCT`
--
ALTER TABLE `CUSTOMER_PRODUCT`
  ADD CONSTRAINT `CUSTOMER_PRODUCT_ibfk_1` FOREIGN KEY (`CustomerAccountNo`) REFERENCES `CUSTOMER` (`CustomerAccountNo`),
  ADD CONSTRAINT `CUSTOMER_PRODUCT_ibfk_2` FOREIGN KEY (`ProdSerNo`) REFERENCES `PRODUCT` (`ProdSerNo`),
  ADD CONSTRAINT `CUSTOMER_PRODUCT_ibfk_3` FOREIGN KEY (`SerPlanNo`) REFERENCES `SERVICE_PLAN` (`SerPlanNo`);

--
-- Constraints for table `INVOICE_SERVICE`
--
ALTER TABLE `INVOICE_SERVICE`
  ADD CONSTRAINT `INVOICE_SERVICE_ibfk_2` FOREIGN KEY (`SerPlanNo`) REFERENCES `SERVICE_PLAN` (`SerPlanNo`),
  ADD CONSTRAINT `INVOICE_SERVICE_ibfk_1` FOREIGN KEY (`InvNo`) REFERENCES `INVOICE` (`InvNo`);

--
-- Constraints for table `TEST_RESULTS`
--
ALTER TABLE `TEST_RESULTS`
  ADD CONSTRAINT `TEST_RESULTS_ibfk_3` FOREIGN KEY (`PartNo`) REFERENCES `INVENTORY` (`PartNo`),
  ADD CONSTRAINT `TEST_RESULTS_ibfk_1` FOREIGN KEY (`DiagNo`) REFERENCES `DIAGNOSTIC` (`DiagNo`),
  ADD CONSTRAINT `TEST_RESULTS_ibfk_2` FOREIGN KEY (`ProdSerNo`) REFERENCES `PRODUCT` (`ProdSerNo`);
